<?php
if (!defined('IN_MLOGIN_API')) {
    exit('Access Denied');
}
require './source/class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once MLOGIN_PLUGIN_PATH."/class/env.class.php";
$actionlist = array(
	'authQuery' => array(1),   
    'authSet'   => array(1),   
);
$uid = $_G['uid'];
$username = $_G['username'];
$groupid = $_G["groupid"];
$action = isset($_GET['action']) ? $_GET['action'] : "get";
try {
    if (!isset($actionlist[$action])) {
        throw new Exception('unknow action');
    }
    $groups = $actionlist[$action];
    if (!empty($groups) && !in_array($groupid, $groups)) {
        throw new Exception('illegal request');
    }
    $res = $action();
    mlogin_env::result(array("data"=>$res));
} catch (Exception $e) {
    mlogin_env::result(array('retcode'=>100010,'retmsg'=>$e->getMessage()));
}
function authQuery(){return C::t('#mlogin#mlogin_auth')->query();}
function authSet(){return C::t('#mlogin#mlogin_auth')->set();}
?>