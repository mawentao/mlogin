<?php
if (!defined('IN_MLOGIN_API')) {
    exit('Access Denied');
}
require './source/class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once MLOGIN_PLUGIN_PATH."/class/env.class.php";
$actionlist = array(
	'login' => array(),        
	'logout' => array(),       
	'changepass' => array(),   
    'profile' => array(),      
    'profile_set' => array(),  
);
$uid = $_G['uid'];
$username = $_G['username'];
$groupid = $_G["groupid"];
$action = isset($_GET['action']) ? $_GET['action'] : "get";
try {
    if (!isset($actionlist[$action])) {
        throw new Exception('unknow action');
    }
    $groups = $actionlist[$action];
    if (!empty($groups) && !in_array($groupid, $groups)) {
        throw new Exception('illegal request');
    }
    $res = $action();
    mlogin_env::result(array("data"=>$res));
} catch (Exception $e) {
    mlogin_env::result(array('retcode'=>100010,'retmsg'=>$e->getMessage()));
}
function login()
{
	
	$seccode = mlogin_validate::getNCParameter('seccode','seccode','string',1024); 
    if (!C::m('#mlogin#mlogin_seccode')->check($seccode)) {
        throw new Exception("验证码错误");
    }
    
    global $_G;
    $username = mlogin_validate::getNCParameter('username','username','string',1024);
    $password = mlogin_validate::getNCParameter('userpass','userpass','string',1024);
    $questionid = 0; 
    $answer = ''; 
    $username = iconv('UTF-8', CHARSET.'//ignore', urldecode($username));
    $answer = iconv('UTF-8', CHARSET.'//ignore', urldecode($answer));
    
    $uid = C::m("#mlogin#mlogin_uc")->logincheck($username, $password, $questionid, $answer);
    if (!is_numeric($uid)) {
        throw new Exception($uid);
    }   
    
    C::m("#mlogin#mlogin_uc")->dologin($uid);
    C::t('#mlogin#mlogin_log')->write("[$username]登录了系统");
    $result = array (
        "username" => $username,
        "uid" => $uid,
    );
    return $result;
}
function logout()
{
	C::m("#mlogin#mlogin_uc")->logout();
	$jumpurl = mlogin_env::get_siteurl()."/plugin.php?id=mlogin";
	header('Location: '.$jumpurl);
}
function changepass()
{
	
	global $uid,$username;
	$oldpass = mlogin_validate::getNCParameter('oldpass','oldpass','string',1024);
	$newpass = mlogin_validate::getNCParameter('newpass','newpass','string',1024);
	if (strlen($newpass)<6) {
		throw new Exception('新密码长度至少6个字符以上');
	}
	$uc = C::m('#mlogin#mlogin_uc');
	if (!$uc->check_user_password($uid,$oldpass)) {
		throw new Exception('旧密码错误');
	}
	
	if (!$uc->update_user_password($username,$newpass)) {
		
	}
	return 0;
}
function profile()
{
    global $uid,$_G;
	$member = mlogin_utils::getvalues($_G['member'],array('uid','username','email'));
	$group = mlogin_utils::getvalues($_G['group'],array('groupid','grouptitle'));
	$sql = "select realname,gender,mobile from ".DB::table('common_member_profile')." where uid=$uid";
	$profile = DB::fetch_first($sql);
	$data = array_merge($member,$group,$profile);
    return $data;
}
function profile_set()
{
    global $uid;
    if ($uid==0) {throw new Exception('请先登录');}
    $data = array (
        'gender' => mlogin_validate::getNCParameter('gender','gender','integer'),
        'mobile' => mlogin_validate::getNCParameter('mobile','mobile','string'),
    );  
    return C::t('common_member_profile')->update($uid,$data);
}
?>