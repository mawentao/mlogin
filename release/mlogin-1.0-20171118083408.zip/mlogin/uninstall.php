<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tables = array (
);
foreach ($tables as $tb) {
    $sql = "DROP TABLE IF EXISTS `".DB::table($tb)."`";
    runquery($sql);
}

$finish = TRUE;
?>