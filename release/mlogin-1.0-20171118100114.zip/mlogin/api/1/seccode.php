<?php
if (!defined('IN_MLOGIN_API')) {
    exit('Access Denied');
}
require './source/class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once MLOGIN_PLUGIN_PATH."/class/env.class.php";
$sc = C::m('#mlogin#mlogin_seccode');
$code = $sc->mkcode(4,false);
$sc->display($code,120,40);
?>