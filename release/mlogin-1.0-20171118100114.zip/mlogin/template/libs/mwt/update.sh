#!/bin/bash

####################################################
# @file:   update.sh
# @author: mawentao
# @create: 2017-06-22 09:17:45
# @modify: 2017-06-22 09:17:45
# @brief:  update.sh
####################################################


cp -r /Users/mawentao/web/localhost:8888/mwtjs/output/mwt/4.0/*.css 4.0
cp -r /Users/mawentao/web/localhost:8888/mwtjs/output/mwt/4.0/*.js 4.0



exit 0
