<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class model_mlogin_usergroup
{
	private $groupmap = array();
	private function fetch_all()
	{
		
		foreach(C::t('common_usergroup')->fetch_all_not(array(6, 7), true) as $group) {
			$groupid = $group['groupid'];
			$this->groupmap[$groupid] = $group;
		}
	}
	public function grouptitle($groupid)
	{
		if (empty($this->groupmap)) {
			$this->fetch_all();
		}
		return isset($this->groupmap[$groupid]) ? $this->groupmap[$groupid]['grouptitle'] : 'unknow_user_group';
	}
	
	public function usergroupselect()
	{
		$groupselect = array();
        foreach(C::t('common_usergroup')->fetch_all_not(array(6, 7), true) as $group) {
            $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
            $groupselect[$group['type']] .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
        }    
        $groupselect = '<option value>空</option>'.
            ($groupselect['special'] ? '<optgroup label="'.lang('admincp','usergroups_special').'">'.$groupselect['special'].'</optgroup>' : ''). 
			'';
        
        $usergroupselect = $groupselect;
		return $usergroupselect;
	}
	
	public function getoptions()
	{
		$res = array(array('text'=>'全部','value'=>0));
		if (empty($groupmap)) {
			$this->fetch_all();
		}
		$map = $this->groupmap;
		foreach ($map as $rgid => $row) {
			if ($rgid==1 || $rgid==10 || ($rgid>=20 && $rgid<=30)) {
				$res[] = array (
					'value' => $rgid,
					'text' => $row['grouptitle'],
				);
			}
		}
		return $res;
	}
}
?>