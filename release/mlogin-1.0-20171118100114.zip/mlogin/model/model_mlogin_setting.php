<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class model_mlogin_setting
{
	
    public function getDefault()
    {
		$setting = array (
            
            'disable_discuz' => 1,
			
			'page_copyright' => 'mlogin.com 2017',
		);
		return $setting;
    }
    
	public function get()
	{
		$setting = $this->getDefault();
		global $_G;
		if (isset($_G['setting']['mlogin_config'])){
			$config = unserialize($_G['setting']['mlogin_config']);
			foreach ($setting as $key => &$item) {
				if (isset($config[$key])) $item = $config[$key];
			}
		}
		return $setting;
	}
}
?>